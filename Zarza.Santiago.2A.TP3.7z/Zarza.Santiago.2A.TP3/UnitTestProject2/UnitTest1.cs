using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EntidadesAbstractas;
using Excepciones;
using ClasesInstanciables;

namespace UnitTestProject2
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void TestUnitarioDniInvalido()
    {
      try
      {
        Alumno a3 = new Alumno(1, "José", "Gutierrez", "asa3r3",
        EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
        Alumno.EEstadoCuenta.Becado);
      }
      catch (Exception e)
      {
        Assert.IsInstanceOfType(e, typeof(DniInvalidoException));
      }
    }
  }
}
