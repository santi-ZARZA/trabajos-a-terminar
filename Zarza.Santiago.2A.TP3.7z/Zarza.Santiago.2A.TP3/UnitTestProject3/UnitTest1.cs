using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EntidadesAbstractas;
using Excepciones;
using ClasesInstanciables;

namespace UnitTestProject3
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void TestUnitarioProfesorNulo()
    {
      Profesor profesor = new Profesor(1, "", "asasa", "1", Persona.ENacionalidad.Argentino);

      Assert.IsNotNull(profesor,"Profesor Nulo");
    }
  }
}
